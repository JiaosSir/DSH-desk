/**
 * @cjiaojiao/dsh-desk-bridge —— 宿主半部。
 *
 * 经 bundle patch（cordis.patch.yml 把行插入 profile 树）挂进宿主进程的极简
 * Cordis 插件：不含业务逻辑，只旁听宿主事件并提供 /api/desktop/* 路由族。
 * 不变式 3 落实点：审批旁听者永远经 next() 委托——桌面壳绝不回答审批，
 * 只把请求镜像给 SSE 订阅者（通知镜像用）。
 * @module @cjiaojiao/dsh-desk-bridge
 */
import type { Context } from '@deepseek-ai/cordis';
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver';
import type { IncomingMessage } from 'node:http';
/** 稳定的 Cordis 插件名。 */
export declare const name = "desk-bridge";
/** 宿主面依赖：webServer 路由注册（dsh-web-app 组合提供）。 */
export declare const inject: string[];
/** 健康检查路由路径（浏览器半部的最小端到端闭环）。 */
export declare const HEALTH_PATH = "/api/desktop/health";
/** SSE 事件流路由路径（审批镜像等桌面事件）。 */
export declare const EVENTS_PATH = "/api/desktop/events";
/** 镜像给浏览器半部的桌面事件（SSE data 帧）。 */
export interface DesktopEvent {
    type: 'approval';
    toolName: string;
    reason?: string;
}
/** 请求是否来自本机回环。 */
export declare function isLoopbackRequest(req: IncomingMessage): boolean;
/** 健康路由：GET 返回 { ok: true }，其余 405。 */
export declare function makeHealthRoute(): WebRoute;
/** 桌面事件总线：宿主内多播（审批旁听 → 所有 SSE 订阅者）。 */
export interface DesktopEventBus {
    publish(event: DesktopEvent): void;
    subscribe(listener: (event: DesktopEvent) => void): () => void;
}
export declare function createEventBus(): DesktopEventBus;
/** SSE 事件流路由：回环 + GET 栅栏，挂住连接推送审批镜像。 */
export declare function makeEventsRoute(bus: DesktopEventBus): WebRoute;
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map