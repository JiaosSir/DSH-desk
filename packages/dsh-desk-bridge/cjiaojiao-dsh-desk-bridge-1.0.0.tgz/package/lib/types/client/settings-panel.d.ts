/**
 * 「桌面」设置区：自启开关、快捷键展示、工作区选择、重启宿主、打开日志、检查更新。
 * 检查更新：安装版支持应用内下载并静默更新（自动退出/覆盖安装/重启）；
 * 便携版不做应用内更新，提示前往 GitHub Releases 手动下载覆盖。
 * 全部经 DeskBridge 调壳侧 IPC；无桥时整个设置区不注册（等价纯浏览器）。
 * @module @cjiaojiao/dsh-desk-bridge/client/settings-panel
 */
import type { ReactElement } from 'react';
import type { SettingsSectionOwnerProps } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { DeskBridge } from './bridge';
export interface DesktopSettingsProps {
    bridge: DeskBridge;
    /** 设置壳提供的关闭入口（离开设置面的流程用）。 */
    close: () => void;
}
/** 槽位注册用的组件工厂：把桥绑进 props，把壳的 close 透传（index.ts 无 JSX）。 */
export declare function DesktopSettingsSection(bridge: DeskBridge): (props: SettingsSectionOwnerProps) => ReactElement;
/** 「桌面」设置区（v1 首发 zh-CN 文案）。 */
export declare function DesktopSettings({ bridge }: DesktopSettingsProps): ReactElement;
//# sourceMappingURL=settings-panel.d.ts.map