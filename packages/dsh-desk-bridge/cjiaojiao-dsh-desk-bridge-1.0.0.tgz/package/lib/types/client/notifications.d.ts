/**
 * 订阅宿主 /api/desktop/events SSE，把审批事件经桥弹系统通知。
 * 纯浏览器（无桥）由调用方保证不启动；断线由 EventSource 自动重连。
 * @module @cjiaojiao/dsh-desk-bridge/client/notifications
 */
import type { DeskBridge } from './bridge';
/** 宿主推送的桌面事件（与宿主半部 DesktopEvent 同构）。 */
export interface ApprovalEvent {
    type: 'approval';
    toolName: string;
    reason?: string;
}
/**
 * 订阅审批镜像并转发为系统通知。
 * @param bridge - 注入的桌面桥。
 * @returns 停止并断开订阅的 disposer。
 */
export declare function subscribeNotifications(bridge: DeskBridge): () => void;
//# sourceMappingURL=notifications.d.ts.map